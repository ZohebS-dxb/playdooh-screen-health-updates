Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Open-HardwareSensors([string]$LibraryDirectory) {
    $script:LibraryDirectory = $LibraryDirectory
    $script:Resolver = [System.ResolveEventHandler]{
        param($sender,$args)
        $file = Join-Path $script:LibraryDirectory (([Reflection.AssemblyName]::new($args.Name)).Name + '.dll')
        if (Test-Path -LiteralPath $file) { return [Reflection.Assembly]::LoadFrom($file) }
        return $null
    }
    [AppDomain]::CurrentDomain.add_AssemblyResolve($script:Resolver)
    Add-Type -Path (Join-Path $LibraryDirectory 'LibreHardwareMonitorLib.dll')
    $computer = New-Object LibreHardwareMonitor.Hardware.Computer
    $computer.IsCpuEnabled = $true; $computer.IsMotherboardEnabled = $true
    $computer.Open()
    return $computer
}

function Read-HardwareTree($Hardware) {
    $Hardware.Update()
    foreach ($sensor in $Hardware.Sensors) {
        [pscustomobject]@{ hardwareType = [string]$Hardware.HardwareType; name = $sensor.Name; type = [string]$sensor.SensorType; value = $sensor.Value; identifier = [string]$sensor.Identifier }
    }
    foreach ($child in $Hardware.SubHardware) { Read-HardwareTree $child }
}

function Get-HardwareSensorInventory($Computer) {
    foreach ($h in $Computer.Hardware) { Read-HardwareTree $h }
}

function Read-HardwareSensors($Computer, [string]$FanIdentifier) {
    $rows = @(Get-HardwareSensorInventory $Computer)
    $cpu = @($rows | Where-Object { $_.hardwareType -eq 'Cpu' -and $_.name -eq 'CPU Package' -and $_.type -eq 'Temperature' })
    $fan = @($rows | Where-Object { $_.identifier -eq $FanIdentifier -and $_.type -eq 'Fan' })
    $load = @($rows | Where-Object { $_.hardwareType -eq 'Cpu' -and $_.name -eq 'CPU Total' -and $_.type -eq 'Load' })
    [pscustomobject]@{
        cpuC = $(if ($cpu.Count -eq 1) { $cpu[0].value } else { $null })
        fanRpm = $(if ($fan.Count -eq 1) { $fan[0].value } else { $null })
        cpuLoad = $(if ($load.Count -eq 1) { $load[0].value } else { $null })
        # Retain every tachometer channel, including zero and unavailable values.
        # A spare motherboard header is not evidence of an installed physical fan.
        fans = @(Get-FanChannelReadings $rows)
    }
}

function Get-FanChannelReadings([object[]]$Inventory) {
    $seen = @{}
    foreach ($row in @($Inventory | Where-Object { $_.type -eq 'Fan' } | Sort-Object identifier)) {
        $id = [string]$row.identifier
        if (-not $id -or $seen.ContainsKey($id)) { continue }
        $seen[$id] = $true
        $rpm = $null
        if ($null -ne $row.value) {
            $n = 0.0
            if ([double]::TryParse([string]$row.value,[Globalization.NumberStyles]::Float,[Globalization.CultureInfo]::InvariantCulture,[ref]$n) -and -not [double]::IsNaN($n) -and -not [double]::IsInfinity($n) -and $n -ge 0 -and $n -le 20000) { $rpm = $n }
        }
        [pscustomobject]@{ identifier = $id; name = [string]$row.name; rpm = $rpm }
    }
}

function Get-ObservationFanIdentifier([object[]]$Inventory) {
    # Explicitly observed channels only. Do not pick the fastest fan or a channel by label alone.
    $known = @('/lpc/it8613e/0/fan/1','/lpc/nct6796dr/0/fan/1')
    $matches = @($Inventory | Where-Object { $_.type -eq 'Fan' -and $_.identifier -in $known })
    if ($matches.Count -eq 1) { return [string]$matches[0].identifier }
    return ''
}

function Read-HardwareSsd([string]$Executable) {
    # Output filenames are unique; no credentials or serial numbers are requested.
    $tempBase = Join-Path ([IO.Path]::GetDirectoryName($Executable)) ([guid]::NewGuid().ToString('N'))
    $stdout = $tempBase + '.json'; $stderr = $tempBase + '.txt'
    try {
        # This SATA device path was demonstrated on the HJS pilot. Verify returned model/protocol.
        $p = Start-Process -FilePath $Executable -ArgumentList '-a -j -q noserial -d ata /dev/sda' -WindowStyle Hidden -PassThru -RedirectStandardOutput $stdout -RedirectStandardError $stderr
        $null = $p.Handle
        if (-not $p.WaitForExit(15000)) { $p.Kill(); $p.WaitForExit(); throw 'SMART query timed out.' }
        $p.WaitForExit()
        $smart = Get-Content -LiteralPath $stdout -Raw | ConvertFrom-Json
        if (-not $smart.PSObject.Properties['model_name'] -or $smart.model_name -notmatch '^asscir\s+256GB$' -or -not $smart.PSObject.Properties['smart_status']) {
            throw 'Unexpected SSD model or inaccessible SMART response; support requires validation.'
        }
        $exitStatus = [int]$smart.smartctl.exit_status
        if (($exitStatus -band 7) -ne 0) { throw 'SMART data collection failed.' }
        $temperature = if ($smart.PSObject.Properties['temperature']) { $smart.temperature.current } else { $null }
        $hours = if ($smart.PSObject.Properties['power_on_time']) { $smart.power_on_time.hours } else { $null }
        if ($null -ne $temperature -and ($temperature -lt 5 -or $temperature -gt 100)) { $temperature = $null }
        if ($null -ne $hours -and ($hours -lt 0 -or $hours -gt 1000000)) { $hours = $null }
        [pscustomobject]@{
            at = [datetimeoffset]::Now.ToString('o'); status = $(if ($smart.smart_status.passed -eq $true) { 'passed' } else { 'failed' })
            model = [string]$smart.model_name; temperatureC = $temperature; powerOnHours = $hours
            remainingLifePercent = $null
            note = 'Vendor-specific attribute decoding is unvalidated. SMART PASSED does not guarantee future health.'
        }
    } catch {
        [pscustomobject]@{ at = [datetimeoffset]::Now.ToString('o'); status = 'unavailable'; model = ''; temperatureC = $null; powerOnHours = $null; remainingLifePercent = $null; note = 'SSD query unavailable; not an SSD failure diagnosis.' }
    } finally {
        foreach ($f in @($stdout,$stderr)) { if (Test-Path -LiteralPath $f) { Remove-Item -LiteralPath $f -Force } }
    }
}

function Close-HardwareSensors($Computer) {
    if ($Computer) { $Computer.Close() }
    if ($script:Resolver) { [AppDomain]::CurrentDomain.remove_AssemblyResolve($script:Resolver) }
}
Export-ModuleMember -Function *
