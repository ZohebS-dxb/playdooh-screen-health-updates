[CmdletBinding()]
param([string]$UpdaterRoot = (Join-Path $env:ProgramData 'PlayDooh\ScreenHealthUpdater'))

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Import-Module (Join-Path $PSScriptRoot 'Updater.Core.psm1') -Force

$logPath = Join-Path $UpdaterRoot 'logs\updater.log'
$mutex = New-Object Threading.Mutex($false, 'Global\PlayDoohScreenHealthUpdater')
if (-not $mutex.WaitOne(0)) { exit 0 }
try {
    $now = Get-Date
    if (Test-RestartGap -At $now) { Write-UpdaterLog $logPath 'Update run skipped for the 04:30 restart window.'; exit 0 }
    $settings = Get-Content -LiteralPath (Join-Path $UpdaterRoot 'config.json') -Raw | ConvertFrom-Json
    $monitorRoot = [string]$settings.monitorRoot
    $monitorConfigPath = Join-Path $monitorRoot 'config.json'
    $monitorConfig = Get-Content -LiteralPath $monitorConfigPath -Raw | ConvertFrom-Json
    $metadata = Get-ReleaseMetadata -Url ([string]$settings.monitorMetadataUrl)
    $localNumber = ConvertTo-WholeVersion -Version ([string]$monitorConfig.monitorVersion)
    $remoteNumber = ConvertTo-WholeVersion -Version ([string]$metadata.version)

    if ($remoteNumber -gt $localNumber) {
        $stage = Join-Path $UpdaterRoot 'staging\monitor'
        $expanded = Expand-VerifiedRelease -Metadata $metadata -StagingRoot $stage -RequiredFiles @('VERSION.txt','ScreenHealth.ps1','ScreenHealth.Core.psm1')
        Assert-PowerShellSyntax -Paths @((Join-Path $expanded 'ScreenHealth.ps1'), (Join-Path $expanded 'ScreenHealth.Core.psm1'))
        $backup = Join-Path $UpdaterRoot ('backups\monitor-' + [string]$monitorConfig.monitorVersion)
        if (Test-Path -LiteralPath $backup) { Remove-Item -LiteralPath $backup -Recurse -Force }
        New-Item -ItemType Directory -Path $backup -Force | Out-Null
        foreach ($name in @('ScreenHealth.ps1','ScreenHealth.Core.psm1','config.json')) { Copy-Item -LiteralPath (Join-Path $monitorRoot $name) -Destination (Join-Path $backup $name) -Force }

        $monitorMutexName = 'Global\PlayDoohScreenHealth-' + ((Get-StableUInt32 -Text ([string]$monitorConfig.screenId)).ToString('X8'))
        $monitorMutex = New-Object Threading.Mutex($false, $monitorMutexName)
        if (-not $monitorMutex.WaitOne(30000)) { throw 'Monitor is busy; update deferred.' }
        try {
            try {
                foreach ($name in @('ScreenHealth.ps1','ScreenHealth.Core.psm1')) {
                    Copy-Item -LiteralPath (Join-Path $expanded $name) -Destination (Join-Path $monitorRoot ($name + '.new')) -Force
                    Move-Item -LiteralPath (Join-Path $monitorRoot ($name + '.new')) -Destination (Join-Path $monitorRoot $name) -Force
                }
                $monitorConfig.monitorVersion = [string]$metadata.version
                $monitorConfig | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath ($monitorConfigPath + '.new') -Encoding UTF8
                Move-Item -LiteralPath ($monitorConfigPath + '.new') -Destination $monitorConfigPath -Force
                Assert-PowerShellSyntax -Paths @((Join-Path $monitorRoot 'ScreenHealth.ps1'), (Join-Path $monitorRoot 'ScreenHealth.Core.psm1'))
                Import-Module (Join-Path $monitorRoot 'ScreenHealth.Core.psm1') -Force
                Write-UpdaterLog $logPath "Monitor updated from v$localNumber to $($metadata.version)."
            }
            catch {
                foreach ($name in @('ScreenHealth.ps1','ScreenHealth.Core.psm1','config.json')) { Copy-Item -LiteralPath (Join-Path $backup $name) -Destination (Join-Path $monitorRoot $name) -Force }
                throw "Monitor installation failed and v$localNumber was restored. $($_.Exception.Message)"
            }
        }
        finally { $monitorMutex.ReleaseMutex(); $monitorMutex.Dispose() }
    }
    else { Write-UpdaterLog $logPath "Monitor is current ($($monitorConfig.monitorVersion)); remote is $($metadata.version)." }

    # Hardware is opt-in; its failure must not interrupt existing monitor/self updates.
    if ($settings.PSObject.Properties['hardwareMetadataUrl'] -and -not [string]::IsNullOrWhiteSpace([string]$settings.hardwareMetadataUrl)) {
        try {
            $hardwareResult = Invoke-HardwareRelease -MetadataUrl ([string]$settings.hardwareMetadataUrl) -ScreenId ([string]$monitorConfig.screenId) -UpdaterRoot $UpdaterRoot
            Write-UpdaterLog $logPath ('Hardware: ' + $hardwareResult)
        } catch { Write-UpdaterLog $logPath ('Hardware deferred: ' + $_.Exception.Message) }
    } elseif (-not $settings.PSObject.Properties['hardwareMetadataUrl']) {
        # Existing fleet configs need no per-PC edit. The private receiver selects the pilot.
        try {
            $plan=Get-HardwareUpdatePlan -MonitorConfig $monitorConfig
            if($null -ne $plan){
                $hardwareResult=Invoke-HardwareRelease -ReleaseMetadata $plan -ScreenId ([string]$monitorConfig.screenId) -UpdaterRoot $UpdaterRoot
                Write-UpdaterLog $logPath ('Hardware: '+$hardwareResult)
            }
        } catch { Write-UpdaterLog $logPath ('Hardware deferred: '+$_.Exception.Message) }
    }

    if ($settings.PSObject.Properties['updaterMetadataUrl'] -and -not [string]::IsNullOrWhiteSpace([string]$settings.updaterMetadataUrl)) {
        $updaterMetadata = Get-ReleaseMetadata -Url ([string]$settings.updaterMetadataUrl)
        $localUpdater = (Get-Content -LiteralPath (Join-Path $UpdaterRoot 'VERSION.txt') -Raw).Trim()
        if ((ConvertTo-WholeVersion ([string]$updaterMetadata.version)) -gt (ConvertTo-WholeVersion $localUpdater)) {
            $selfStage = Join-Path $UpdaterRoot 'staging\updater'
            $selfExpanded = Expand-VerifiedRelease -Metadata $updaterMetadata -StagingRoot $selfStage -RequiredFiles @('VERSION.txt','Updater.ps1','Updater.Core.psm1')
            Assert-PowerShellSyntax -Paths @((Join-Path $selfExpanded 'Updater.ps1'), (Join-Path $selfExpanded 'Updater.Core.psm1'))
            $pending = [ordered]@{ version = [string]$updaterMetadata.version; sha256 = [string]$updaterMetadata.sha256; expandedPath = $selfExpanded }
            $pending | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $UpdaterRoot 'pending-updater.json') -Encoding UTF8
            Write-UpdaterLog $logPath "Updater $($updaterMetadata.version) verified and staged for the next daily run."
        }
    }
}
catch { Write-UpdaterLog $logPath ('ERROR ' + $_.Exception.Message); exit 1 }
finally { $mutex.ReleaseMutex(); $mutex.Dispose() }
