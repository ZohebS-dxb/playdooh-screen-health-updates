Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function ConvertTo-WholeVersion {
    param([Parameter(Mandatory = $true)][string]$Version)
    if ($Version -cnotmatch '^v([1-9][0-9]*)$') { throw "Invalid version '$Version'. Expected v1, v2, v3, etc." }
    return [int64]$Matches[1]
}

function Get-StableUInt32 {
    param([Parameter(Mandatory = $true)][string]$Text)
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToUInt32($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($Text)), 0) }
    finally { $sha.Dispose() }
}

function Get-UpdaterCheckTime {
    param([Parameter(Mandatory = $true)][string]$ScreenId)
    # One of 1,409 safe minutes per day. 04:15 through 04:45 inclusive are excluded.
    $slot = (Get-StableUInt32 -Text ($ScreenId + '|updater')) % 1409
    $minuteOfDay = if ($slot -lt 255) { $slot } else { $slot + 31 }
    return [TimeSpan]::FromMinutes($minuteOfDay)
}

function Test-RestartGap {
    param([Parameter(Mandatory = $true)][datetime]$At)
    $minute = ($At.Hour * 60) + $At.Minute
    return ($minute -ge 255 -and $minute -le 285)
}

function Write-UpdaterLog {
    param([Parameter(Mandatory = $true)][string]$Path, [Parameter(Mandatory = $true)][string]$Message)
    $directory = Split-Path -Parent $Path
    if (-not (Test-Path -LiteralPath $directory)) { New-Item -ItemType Directory -Path $directory -Force | Out-Null }
    if ((Test-Path -LiteralPath $Path) -and (Get-Item -LiteralPath $Path).Length -gt 512KB) {
        $previous = $Path + '.previous'
        if (Test-Path -LiteralPath $previous) { Remove-Item -LiteralPath $previous -Force }
        Move-Item -LiteralPath $Path -Destination $previous
    }
    Add-Content -LiteralPath $Path -Value ('{0:o} {1}' -f (Get-Date), $Message) -Encoding UTF8
}

function Get-ReleaseMetadata {
    param([Parameter(Mandatory = $true)][string]$Url)
    if (-not ([uri]$Url).Scheme.Equals('https', [StringComparison]::OrdinalIgnoreCase)) { throw 'Metadata URL must use HTTPS.' }
    $metadata = Invoke-RestMethod -Uri $Url -Method Get -UseBasicParsing -TimeoutSec 30
    [void](ConvertTo-WholeVersion -Version ([string]$metadata.version))
    if ([string]::IsNullOrWhiteSpace([string]$metadata.packageUrl) -or -not ([uri][string]$metadata.packageUrl).Scheme.Equals('https', [StringComparison]::OrdinalIgnoreCase)) { throw 'Package URL must use HTTPS.' }
    if ([string]$metadata.sha256 -notmatch '^[A-Fa-f0-9]{64}$') { throw 'Metadata SHA-256 must contain exactly 64 hexadecimal characters.' }
    return $metadata
}

function Assert-FileChecksum {
    param([Parameter(Mandatory = $true)][string]$Path, [Parameter(Mandatory = $true)][string]$Expected)
    $actual = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash
    if (-not $actual.Equals($Expected, [StringComparison]::OrdinalIgnoreCase)) { throw "SHA-256 verification failed. Expected $Expected; received $actual." }
}

function Assert-PowerShellSyntax {
    param([Parameter(Mandatory = $true)][string[]]$Paths)
    foreach ($path in $Paths) {
        $tokens = $null; $errors = $null
        [void][Management.Automation.Language.Parser]::ParseFile($path, [ref]$tokens, [ref]$errors)
        if (@($errors).Count -gt 0) { throw "PowerShell validation failed for $(Split-Path -Leaf $path): $($errors[0].Message)" }
    }
}

function Expand-VerifiedRelease {
    param($Metadata, [string]$StagingRoot, [string[]]$RequiredFiles)
    if (Test-Path -LiteralPath $StagingRoot) { Remove-Item -LiteralPath $StagingRoot -Recurse -Force }
    New-Item -ItemType Directory -Path $StagingRoot -Force | Out-Null
    $zipPath = Join-Path $StagingRoot 'package.zip'
    Invoke-WebRequest -Uri ([string]$Metadata.packageUrl) -OutFile $zipPath -UseBasicParsing -TimeoutSec 120
    Assert-FileChecksum -Path $zipPath -Expected ([string]$Metadata.sha256)
    $expanded = Join-Path $StagingRoot 'expanded'
    Expand-Archive -LiteralPath $zipPath -DestinationPath $expanded -Force
    foreach ($name in $RequiredFiles) {
        if (-not (Test-Path -LiteralPath (Join-Path $expanded $name) -PathType Leaf)) { throw "Release package is missing '$name'." }
    }
    $versionText = (Get-Content -LiteralPath (Join-Path $expanded 'VERSION.txt') -Raw).Trim()
    if ($versionText -ne [string]$Metadata.version) { throw "Package version '$versionText' does not match metadata version '$($Metadata.version)'." }
    return $expanded
}

function Invoke-HardwareRelease {
    param([string]$MetadataUrl,[string]$ScreenId,[string]$UpdaterRoot,
        [string]$HardwareRoot=(Join-Path $env:ProgramData 'PlayDooh\HardwarePilot'),
        [scriptblock]$RunScript={param($Path,$AllowPlaceholder)
            $arguments=@('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',$Path)
            if($AllowPlaceholder){$arguments+='-ObserveUnidentifiedHardware'}
            & (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe') @arguments | Out-Null
            if($LASTEXITCODE -ne 0){throw 'Hardware setup script failed; see local device diagnostics.'}
        })
    if($ScreenId -notmatch '^\d{4}$' -or $ScreenId -eq '0000'){return 'Skipped: valid player identity required.'}
    $metadata=Get-ReleaseMetadata -Url $MetadataUrl
    if(-not $metadata.PSObject.Properties['enabled'] -or $metadata.enabled -isnot [bool] -or -not $metadata.enabled){return 'Disabled.'}
    if(-not $metadata.PSObject.Properties['screenIds'] -or @($metadata.screenIds).Count -eq 0){throw 'Explicit hardware screen allowlist required.'}
    foreach($id in @($metadata.screenIds)){if($id -isnot [string] -or $id -notmatch '^\d{4}$' -or $id -eq '0000'){throw 'Invalid hardware screen allowlist.'}}
    if($ScreenId -notin @($metadata.screenIds)){return 'Skipped: player not selected.'}
    if(-not $metadata.PSObject.Properties['mode'] -or $metadata.mode -cne 'Observe'){throw 'This updater release permits observation only.'}
    $enableDaily=$false
    if($metadata.PSObject.Properties['enableDailyReporting']){
        if($metadata.enableDailyReporting -isnot [bool]){throw 'Invalid daily reporting flag.'}
        $enableDaily=$metadata.enableDailyReporting
    }
    if($enableDaily -and $ScreenId -cne '0105'){throw 'Daily activation is approved only for Pranzo 0105.'}
    $board=Get-CimInstance Win32_BaseBoard;$cpu=Get-CimInstance Win32_Processor
    if([string]$cpu.Name -notmatch '\bi7-11700\b'){return 'Skipped: unsupported CPU.'}
    $placeholder=([string]$board.Product -in @('Default string','To be filled by O.E.M.',''))
    if([string]$board.Product -ne 'HJS-OPSH510A04' -and -not($placeholder -and $ScreenId -eq '0105')){return 'Skipped: motherboard requires review.'}
    $configPath=Join-Path $HardwareRoot 'config.json';$existing=$null
    if(Test-Path -LiteralPath $configPath){
        $existing=Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json
        if($existing.screenId -cne $ScreenId){throw 'Installed hardware player identity mismatch.'}
        if($existing.mode -ne 'Observe' -and -not($ScreenId -eq '0105' -and $existing.mode -eq 'Send' -and $existing.PSObject.Properties['reportingPolicy'] -and $existing.reportingPolicy -eq 'daily-v1')){return 'Skipped: unreviewed sending configuration.'}
    } elseif(-not $metadata.PSObject.Properties['installMissing'] -or $metadata.installMissing -isnot [bool] -or -not $metadata.installMissing){return 'Skipped: no installed hardware pilot.'}
    $receipt=Join-Path $HardwareRoot 'updater-version.txt'
    $current=$false
    if(Test-Path -LiteralPath $receipt){$current=(ConvertTo-WholeVersion (Get-Content -LiteralPath $receipt -Raw).Trim()) -ge (ConvertTo-WholeVersion $metadata.version)}
    $alreadyDaily=$null -ne $existing -and $existing.mode -eq 'Send' -and $existing.PSObject.Properties['reportingPolicy'] -and $existing.reportingPolicy -eq 'daily-v1'
    if($current -and (-not $enableDaily -or $alreadyDaily)){return 'Current.'}
    if($enableDaily -and $null -eq $existing){throw 'Daily activation requires the already tested installed pilot.'}
    $required=@('VERSION.txt','Install-HardwarePilot.ps1','Update-ObservationPilot.ps1','src\Hardware.Core.psm1','src\Hardware.Readings.psm1','src\Hardware.Pilot.ps1')
    if($enableDaily){$required+='Enable-DailyReporting.ps1'}
    $expanded=Expand-VerifiedRelease -Metadata $metadata -StagingRoot (Join-Path $UpdaterRoot 'staging\hardware') -RequiredFiles $required
    Assert-PowerShellSyntax -Paths @($required | Where-Object {$_ -ne 'VERSION.txt'} | ForEach-Object {Join-Path $expanded $_})
    $script=if($null -eq $existing){'Install-HardwarePilot.ps1'}else{'Update-ObservationPilot.ps1'}
    if(-not $current){& $RunScript (Join-Path $expanded $script) ($placeholder -and $null -eq $existing)}
    if(-not(Test-Path -LiteralPath $configPath)){throw 'Hardware setup did not produce a configuration.'}
    $after=Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json
    $expectedMode=if($null -eq $existing){'Observe'}else{[string]$existing.mode}
    if($after.screenId -cne $ScreenId -or $after.mode -ne $expectedMode){throw 'Hardware setup post-check failed.'}
    if($expectedMode -eq 'Send' -and $after.reportingPolicy -ne 'daily-v1'){throw 'Daily reporting policy was not preserved.'}
    if($enableDaily -and -not $alreadyDaily){
        & $RunScript (Join-Path $expanded 'Enable-DailyReporting.ps1') $false
        $after=Get-Content -LiteralPath $configPath -Raw|ConvertFrom-Json
        if($after.screenId -cne '0105' -or $after.mode -cne 'Send' -or -not $after.PSObject.Properties['reportingPolicy'] -or $after.reportingPolicy -cne 'daily-v1'){throw 'Daily reporting activation was not confirmed.'}
        $expectedMode='Send'
    }
    Set-Content -LiteralPath $receipt -Value ([string]$metadata.version) -Encoding ASCII
    return ('Hardware pilot updated to '+$metadata.version+'; mode '+$expectedMode+'.')
}

Export-ModuleMember -Function *
