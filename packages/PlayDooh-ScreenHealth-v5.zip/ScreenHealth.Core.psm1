Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Get-StableUInt32 {
    param([Parameter(Mandatory = $true)][string]$Text)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
        $hash = $sha.ComputeHash($bytes)
        return [System.BitConverter]::ToUInt32($hash, 0)
    }
    finally { $sha.Dispose() }
}

function Get-SafeCheckMinute {
    param([Parameter(Mandatory = $true)][string]$ScreenId)
    $safeMinutes = @(0..14) + @(45..59)
    return $safeMinutes[(Get-StableUInt32 -Text ($ScreenId + '|check')) % $safeMinutes.Count]
}

function Get-UploadSlot {
    param([Parameter(Mandatory = $true)][string]$ScreenId)
    # Allowed windows: 00:00-04:15 inclusive and 04:45-08:00 inclusive.
    # This deliberately leaves the 04:16-04:44 period clear around the fleet's 04:30 restart.
    $slot = (Get-StableUInt32 -Text ($ScreenId + '|upload')) % 452
    $minuteOfDay = if ($slot -lt 256) { $slot } else { $slot + 29 }
    return [TimeSpan]::FromMinutes($minuteOfDay)
}

function Test-RestartGap {
    param([Parameter(Mandatory = $true)][datetime]$At)
    $minutes = ($At.Hour * 60) + $At.Minute
    return ($minutes -ge 255 -and $minutes -lt 285)
}

function ConvertTo-DateKey {
    param([Parameter(Mandatory = $true)][datetime]$Date)
    return $Date.ToString('yyyy-MM-dd', [Globalization.CultureInfo]::InvariantCulture)
}

function ConvertFrom-DateKey {
    param([Parameter(Mandatory = $true)][string]$DateKey)
    return [datetime]::ParseExact($DateKey, 'yyyy-MM-dd', [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::AssumeLocal)
}

function Get-ReportWeek {
    param([Parameter(Mandatory = $true)][datetime]$At)
    $daysSinceSaturday = (([int]$At.DayOfWeek - [int][DayOfWeek]::Saturday) + 7) % 7
    return (ConvertTo-DateKey -Date $At.Date.AddDays(-$daysSinceSaturday))
}

function Get-ReportDateKeys {
    param([Parameter(Mandatory = $true)][string]$ReportWeek)
    $saturday = ConvertFrom-DateKey -DateKey $ReportWeek
    $result = @()
    for ($offset = 7; $offset -ge 1; $offset--) {
        $result += ConvertTo-DateKey -Date $saturday.AddDays(-$offset)
    }
    return $result
}

function New-EmptyState {
    param([Parameter(Mandatory = $true)][string]$ScreenId)
    return [pscustomobject][ordered]@{
        schemaVersion      = 1
        screenId           = $ScreenId
        daily              = [pscustomobject]@{}
        pending            = @()
        lastGeneratedWeek  = $null
        lastSuccessfulWeek = $null
        lastCheckAt        = $null
        lastUploadAt       = $null
        lastError          = $null
        lastGeneratedDaily = $null
        deliveredDaily     = @()
    }
}

function Get-InferredMonitoringStart {
    param(
        [Parameter(Mandatory = $true)]$State,
        [Parameter(Mandatory = $true)][int]$CheckMinute,
        [datetime]$Fallback = (Get-Date)
    )
    $entries = @($State.daily.PSObject.Properties | Sort-Object Name)
    if ($entries.Count -eq 0) { return $Fallback }
    $first = $entries[0].Value
    $date = ConvertFrom-DateKey -DateKey ([string]$entries[0].Name)
    $checks = [Math]::Max(1, [int]$first.checksRun)
    if (-not [string]::IsNullOrWhiteSpace([string]$first.lastCheckAt)) {
        try {
            $last = [datetime]::Parse([string]$first.lastCheckAt)
            $estimate = $last.AddHours(-($checks - 1))
            if ($estimate.Date -eq $date.Date) { return $estimate }
        }
        catch { }
    }
    return $date.AddMinutes($CheckMinute)
}

function Read-State {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$ScreenId
    )
    if (-not (Test-Path -LiteralPath $Path)) { return New-EmptyState -ScreenId $ScreenId }
    $state = Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json
    if ([int]$state.schemaVersion -ne 1 -or [string]$state.screenId -ne $ScreenId) {
        throw 'The local state file does not match this screen.'
    }
    return $state
}

function Write-State {
    param(
        [Parameter(Mandatory = $true)]$State,
        [Parameter(Mandatory = $true)][string]$Path
    )
    $directory = Split-Path -Parent $Path
    if (-not (Test-Path -LiteralPath $directory)) { New-Item -ItemType Directory -Path $directory -Force | Out-Null }
    $temporary = $Path + '.new'
    $State | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $temporary -Encoding UTF8
    Move-Item -LiteralPath $temporary -Destination $Path -Force
}

function Get-DailyEntry {
    param($State, [string]$DateKey)
    $property = $State.daily.PSObject.Properties[$DateKey]
    if ($null -ne $property) { return $property.Value }
    return $null
}

function Set-DailyEntry {
    param($State, [string]$DateKey, $Value)
    $property = $State.daily.PSObject.Properties[$DateKey]
    if ($null -ne $property) { $property.Value = $Value }
    else { $State.daily | Add-Member -NotePropertyName $DateKey -NotePropertyValue $Value }
}

function Add-ConnectivityResult {
    param(
        [Parameter(Mandatory = $true)]$State,
        [Parameter(Mandatory = $true)][datetime]$At,
        [Parameter(Mandatory = $true)][bool]$Online
    )
    if (Test-RestartGap -At $At) { return $State }
    $dateKey = ConvertTo-DateKey -Date $At
    $entry = Get-DailyEntry -State $State -DateKey $dateKey
    if ($null -eq $entry) {
        $entry = [pscustomobject]@{ onlineChecks = 0; checksRun = 0; lastCheckAt = $null }
    }
    $entry.checksRun = [int]$entry.checksRun + 1
    if ($Online) { $entry.onlineChecks = [int]$entry.onlineChecks + 1 }
    $entry.lastCheckAt = $At.ToString('o')
    Set-DailyEntry -State $State -DateKey $dateKey -Value $entry
    $State.lastCheckAt = $At.ToString('o')
    return $State
}

function Remove-OldDailyEntries {
    param($State, [datetime]$At, [int]$KeepDays = 45)
    $cutoff = $At.Date.AddDays(-($KeepDays - 1))
    foreach ($property in @($State.daily.PSObject.Properties)) {
        if ((ConvertFrom-DateKey -DateKey $property.Name) -lt $cutoff) {
            $State.daily.PSObject.Properties.Remove($property.Name)
        }
    }
}

function Get-ExpectedChecksForDate {
    param(
        [Parameter(Mandatory = $true)][datetime]$Date,
        [Parameter(Mandatory = $true)][datetime]$MonitoringStartedAt,
        [Parameter(Mandatory = $true)][int]$CheckMinute,
        [datetime]$WindowEnd
    )
    $dayStart = $Date.Date
    $dayEnd = $dayStart.AddDays(1)
    if ($MonitoringStartedAt -ge $dayEnd) { return 0 }
    $effectiveStart = if ($MonitoringStartedAt -gt $dayStart) { $MonitoringStartedAt } else { $dayStart }
    $effectiveEnd = if ($PSBoundParameters.ContainsKey('WindowEnd') -and $WindowEnd -lt $dayEnd) { $WindowEnd } else { $dayEnd }
    if ($effectiveEnd -le $effectiveStart) { return 0 }

    $count = 0
    for ($hour = 0; $hour -lt 24; $hour++) {
        $scheduled = $dayStart.AddHours($hour).AddMinutes($CheckMinute)
        if ($scheduled -ge $effectiveStart -and $scheduled -lt $effectiveEnd -and -not (Test-RestartGap -At $scheduled)) { $count++ }
    }
    return $count
}

function Get-DailySummaries {
    param(
        [Parameter(Mandatory = $true)]$State,
        [Parameter(Mandatory = $true)][string]$ReportWeek,
        [Parameter(Mandatory = $true)][datetime]$MonitoringStartedAt,
        [Parameter(Mandatory = $true)][int]$CheckMinute
    )
    $summaries = @()
    foreach ($dateKey in (Get-ReportDateKeys -ReportWeek $ReportWeek)) {
        $entry = Get-DailyEntry -State $State -DateKey $dateKey
        $checksRun = if ($null -eq $entry) { 0 } else { [int]$entry.checksRun }
        $expected = Get-ExpectedChecksForDate -Date (ConvertFrom-DateKey -DateKey $dateKey) -MonitoringStartedAt $MonitoringStartedAt -CheckMinute $CheckMinute
        # An immediate installation check can create one extra measurement outside the normal hourly slot.
        # Never allow coverage to exceed 100% because of that harmless extra check.
        if ($checksRun -gt $expected) { $expected = $checksRun }
        $summaries += [pscustomobject][ordered]@{
            date           = $dateKey
            onlineChecks   = if ($null -eq $entry) { 0 } else { [int]$entry.onlineChecks }
            checksRun      = $checksRun
            expectedChecks = [int]$expected
        }
    }
    return $summaries
}

function Get-LocalSevenDayStatus {
    param(
        [Parameter(Mandatory = $true)]$State,
        [Parameter(Mandatory = $true)][datetime]$MonitoringStartedAt,
        [Parameter(Mandatory = $true)][int]$CheckMinute,
        [datetime]$At = (Get-Date)
    )
    $result = @()
    for ($offset = 6; $offset -ge 0; $offset--) {
        $date = $At.Date.AddDays(-$offset)
        $dateKey = ConvertTo-DateKey -Date $date
        $entry = Get-DailyEntry -State $State -DateKey $dateKey
        $checksRun = if ($null -eq $entry) { 0 } else { [int]$entry.checksRun }
        $onlineChecks = if ($null -eq $entry) { 0 } else { [int]$entry.onlineChecks }
        $offlineChecks = [Math]::Max(0, $checksRun - $onlineChecks)
        $windowEnd = if ($date -eq $At.Date) { $At } else { $date.AddDays(1) }
        $expected = Get-ExpectedChecksForDate -Date $date -MonitoringStartedAt $MonitoringStartedAt -CheckMinute $CheckMinute -WindowEnd $windowEnd
        if ($checksRun -gt $expected) { $expected = $checksRun }
        $coverage = if ($expected -eq 0) { 'N/A' } else { '{0:0.0}%' -f (($checksRun / [double]$expected) * 100) }
        $status = if ($expected -eq 0) { 'Not monitoring yet' }
        elseif ($checksRun -eq 0) { 'No sample' }
        elseif ($offlineChecks -gt 0) { 'Offline detected' }
        elseif ($checksRun -ge $expected) { 'All online' }
        elseif ($date -eq $At.Date) { 'Online so far' }
        else { 'Partial data' }

        $result += [pscustomobject][ordered]@{
            Date     = $dateKey
            Day      = $date.ToString('ddd', [Globalization.CultureInfo]::InvariantCulture)
            Online   = $onlineChecks
            Offline  = $offlineChecks
            Checks   = ('{0}/{1}' -f $checksRun, $expected)
            Coverage = $coverage
            Result   = $status
        }
    }
    return $result
}

function Get-UnexpectedShutdownCount {
    param(
        [Parameter(Mandatory = $true)][datetime]$Start,
        [Parameter(Mandatory = $true)][datetime]$End
    )
    try {
        $events = @(Get-WinEvent -FilterHashtable @{ LogName = 'System'; Id = 41, 6008; StartTime = $Start; EndTime = $End } -ErrorAction Stop | Sort-Object TimeCreated)
        $clusters = @()
        foreach ($event in $events) {
            $time = [datetime]$event.TimeCreated
            if ($clusters.Count -eq 0 -or ($time - $clusters[-1]).Duration().TotalMinutes -gt 10) { $clusters += $time }
        }
        return $clusters.Count
    }
    catch { return 0 }
}

function New-WeeklyReport {
    param(
        [Parameter(Mandatory = $true)]$State,
        [Parameter(Mandatory = $true)][string]$ScreenId,
        [Parameter(Mandatory = $true)][string]$ReportWeek,
        [Parameter(Mandatory = $true)][datetime]$CreatedAt,
        [Parameter(Mandatory = $true)][datetime]$MonitoringStartedAt,
        [Parameter(Mandatory = $true)][int]$CheckMinute,
        [Parameter(Mandatory = $true)][string]$MonitorVersion,
        [scriptblock]$CrashCounter
    )
    $end = ConvertFrom-DateKey -DateKey $ReportWeek
    $start = $end.AddDays(-7)
    $crashes = if ($null -ne $CrashCounter) { & $CrashCounter $start $end } else { Get-UnexpectedShutdownCount -Start $start -End $end }
    return [pscustomobject][ordered]@{
        version           = 1
        monitorVersion    = $MonitorVersion
        screenId          = $ScreenId
        reportId          = ($ScreenId + ':' + $ReportWeek + ':' + $MonitorVersion)
        reportWeek        = $ReportWeek
        sentAt            = $CreatedAt.ToString('o')
        monitoringStartedAt = $MonitoringStartedAt.ToString('o')
        crashesThisWeek   = [int]$crashes
        days              = @(Get-DailySummaries -State $State -ReportWeek $ReportWeek -MonitoringStartedAt $MonitoringStartedAt -CheckMinute $CheckMinute)
    }
}

function Get-RollingWindowMetrics {
    param(
        [Parameter(Mandatory = $true)]$State,
        [Parameter(Mandatory = $true)][datetime]$WindowEnd,
        [Parameter(Mandatory = $true)][int]$Days,
        [Parameter(Mandatory = $true)][datetime]$MonitoringStartedAt,
        [Parameter(Mandatory = $true)][int]$CheckMinute
    )
    $online = 0; $collected = 0; $expected = 0; $details = @()
    for ($offset = $Days; $offset -ge 1; $offset--) {
        $date = $WindowEnd.Date.AddDays(-$offset)
        $dateKey = ConvertTo-DateKey -Date $date
        $entry = Get-DailyEntry -State $State -DateKey $dateKey
        $dayCollected = if ($null -eq $entry) { 0 } else { [int]$entry.checksRun }
        $dayOnline = if ($null -eq $entry) { 0 } else { [int]$entry.onlineChecks }
        $dayExpected = Get-ExpectedChecksForDate -Date $date -MonitoringStartedAt $MonitoringStartedAt -CheckMinute $CheckMinute
        if ($dayCollected -gt $dayExpected) { $dayExpected = $dayCollected }
        $online += $dayOnline; $collected += $dayCollected; $expected += $dayExpected
        $details += [pscustomobject][ordered]@{ date = $dateKey; onlineChecks = $dayOnline; checksRun = $dayCollected; expectedChecks = $dayExpected }
    }
    return [pscustomobject][ordered]@{
        days = $Days
        onlineChecks = $online
        checksCollected = $collected
        checksExpected = $expected
        # Online availability is measured across the whole expected monitoring
        # window. A missing check is therefore unavailable, just like a recorded
        # check that could not reach the internet.
        onlinePercent = if ($expected -eq 0) { $null } else { [Math]::Round(($online / [double]$expected) * 100, 1) }
        turnedOnPercent = if ($expected -eq 0) { $null } else { [Math]::Round(($collected / [double]$expected) * 100, 1) }
        daily = $details
    }
}

function Add-DailySnapshotReport {
    param(
        [Parameter(Mandatory = $true)]$State,
        [Parameter(Mandatory = $true)][string]$ScreenId,
        [Parameter(Mandatory = $true)][datetime]$At,
        [Parameter(Mandatory = $true)][datetime]$MonitoringStartedAt,
        [Parameter(Mandatory = $true)][int]$CheckMinute,
        [Parameter(Mandatory = $true)][string]$MonitorVersion,
        [string]$UpdaterVersion = '',
        [int]$CrashesLast7Days = 0,
        [int]$CrashesLast30Days = 0
    )
    if (-not $State.PSObject.Properties['lastGeneratedDaily']) { $State | Add-Member -NotePropertyName lastGeneratedDaily -NotePropertyValue $null }
    if (-not $State.PSObject.Properties['deliveredDaily']) { $State | Add-Member -NotePropertyName deliveredDaily -NotePropertyValue @() }
    $reportDate = ConvertTo-DateKey -Date $At
    if ([string]$State.lastGeneratedDaily -eq $reportDate -or @($State.pending | Where-Object { $_.PSObject.Properties['reportType'] -and [string]$_.reportType -eq 'dailySnapshot' -and [string]$_.reportDate -eq $reportDate }).Count -gt 0) { return $State }
    $seven = Get-RollingWindowMetrics -State $State -WindowEnd $At.Date -Days 7 -MonitoringStartedAt $MonitoringStartedAt -CheckMinute $CheckMinute
    $thirty = Get-RollingWindowMetrics -State $State -WindowEnd $At.Date -Days 30 -MonitoringStartedAt $MonitoringStartedAt -CheckMinute $CheckMinute
    $report = [pscustomobject][ordered]@{
        version = 2
        reportType = 'dailySnapshot'
        monitorVersion = $MonitorVersion
        updaterVersion = $UpdaterVersion
        screenId = $ScreenId
        reportId = ($ScreenId + ':daily:' + $reportDate)
        reportDate = $reportDate
        sentAt = $At.ToString('o')
        monitoringStartedAt = $MonitoringStartedAt.ToString('o')
        crashesLast7Days = $CrashesLast7Days
        crashesLast30Days = $CrashesLast30Days
        rolling7 = $seven
        rolling30 = $thirty
    }
    $State.pending = @($State.pending) + @($report)
    $State.lastGeneratedDaily = $reportDate
    return $State
}

function Add-MissingWeeklyReports {
    param(
        [Parameter(Mandatory = $true)]$State,
        [Parameter(Mandatory = $true)][string]$ScreenId,
        [Parameter(Mandatory = $true)][datetime]$At,
        [Parameter(Mandatory = $true)][datetime]$MonitoringStartedAt,
        [Parameter(Mandatory = $true)][int]$CheckMinute,
        [Parameter(Mandatory = $true)][string]$MonitorVersion,
        [scriptblock]$CrashCounter
    )
    $latestWeek = Get-ReportWeek -At $At
    $latest = ConvertFrom-DateKey -DateKey $latestWeek

    # The first valid report week is the first Saturday boundary after monitoring began.
    # This prevents a newly installed monitor from generating a fake late/no-show report
    # for a week that ended before the monitor even existed.
    $daysToSaturday = (([int][DayOfWeek]::Saturday - [int]$MonitoringStartedAt.DayOfWeek) + 7) % 7
    if ($daysToSaturday -eq 0) { $daysToSaturday = 7 }
    $firstValidWeekDate = $MonitoringStartedAt.Date.AddDays($daysToSaturday)
    if ($firstValidWeekDate -gt $latest) { return $State }

    $weeks = @()
    if ([string]::IsNullOrWhiteSpace([string]$State.lastGeneratedWeek)) {
        $cursor = $firstValidWeekDate
    }
    else {
        $cursor = (ConvertFrom-DateKey -DateKey ([string]$State.lastGeneratedWeek)).AddDays(7)
        if ($cursor -lt $firstValidWeekDate) { $cursor = $firstValidWeekDate }
    }
    while ($cursor -le $latest) {
        $weeks += ConvertTo-DateKey -Date $cursor
        $cursor = $cursor.AddDays(7)
    }
    foreach ($week in $weeks) {
        $State.pending = @($State.pending) + @(New-WeeklyReport -State $State -ScreenId $ScreenId -ReportWeek $week -CreatedAt $At -MonitoringStartedAt $MonitoringStartedAt -CheckMinute $CheckMinute -MonitorVersion $MonitorVersion -CrashCounter $CrashCounter)
        $State.lastGeneratedWeek = $week
    }
    $State.pending = @($State.pending | Sort-Object reportWeek)
    return $State
}

function Protect-ReceiverToken {
    param([Parameter(Mandatory = $true)][string]$Token)
    Add-Type -AssemblyName System.Security -ErrorAction SilentlyContinue
    $bytes = [Text.Encoding]::UTF8.GetBytes($Token)
    $protected = [System.Security.Cryptography.ProtectedData]::Protect(
        $bytes,
        $null,
        [System.Security.Cryptography.DataProtectionScope]::LocalMachine
    )
    return [Convert]::ToBase64String($protected)
}

function Unprotect-ReceiverToken {
    param([Parameter(Mandatory = $true)][string]$ProtectedToken)
    Add-Type -AssemblyName System.Security -ErrorAction SilentlyContinue
    $bytes = [Convert]::FromBase64String($ProtectedToken)
    $plain = [System.Security.Cryptography.ProtectedData]::Unprotect(
        $bytes,
        $null,
        [System.Security.Cryptography.DataProtectionScope]::LocalMachine
    )
    return [Text.Encoding]::UTF8.GetString($plain)
}

function Test-InternetOnline {
    param([int]$TimeoutSeconds = 5)
    $targets = @(
        'https://www.google.com/generate_204',
        'https://www.cloudflare.com/cdn-cgi/trace'
    )
    foreach ($target in $targets) {
        try {
            $response = Invoke-WebRequest -Uri $target -Method Get -TimeoutSec $TimeoutSeconds -UseBasicParsing
            if ($null -ne $response -and [int]$response.StatusCode -ge 200 -and [int]$response.StatusCode -lt 400) { return $true }
        }
        catch { }
    }
    return $false
}

function Test-ReceiverOnline {
    param([Parameter(Mandatory = $true)][string]$Endpoint, [int]$TimeoutSeconds = 5)
    try {
        $response = Invoke-RestMethod -Uri $Endpoint -Method Get -TimeoutSec $TimeoutSeconds -UseBasicParsing
        return ($response.ok -eq $true)
    }
    catch { return $false }
}

function Send-PendingReports {
    param(
        [Parameter(Mandatory = $true)]$State,
        [Parameter(Mandatory = $true)][string]$Endpoint,
        [Parameter(Mandatory = $true)][string]$Token,
        [Parameter(Mandatory = $true)][datetime]$At,
        [int]$MaximumReports = 12,
        [scriptblock]$Sender
    )
    $sent = 0
    while (@($State.pending).Count -gt 0 -and $sent -lt $MaximumReports) {
        $report = $State.pending[0]
        $payload = [ordered]@{}
        foreach ($property in $report.PSObject.Properties) { $payload[$property.Name] = $property.Value }
        $payload.token = $Token
        try {
            $result = if ($null -ne $Sender) { & $Sender $Endpoint $payload }
            else { Invoke-RestMethod -Uri $Endpoint -Method Post -ContentType 'text/plain; charset=utf-8' -Body ($payload | ConvertTo-Json -Depth 8 -Compress) -TimeoutSec 30 -UseBasicParsing }
            if ($result.ok -ne $true -or ($result.accepted -ne $true -and $result.dryRun -ne $true)) {
                throw ([string]$result.error)
            }
            $State.lastSuccessfulWeek = [string]$report.reportWeek
            $State.pending = @($State.pending | Select-Object -Skip 1)
            $State.lastUploadAt = $At.ToString('o')
            $State.lastError = $null
            if ($report.PSObject.Properties['reportType'] -and [string]$report.reportType -eq 'dailySnapshot') {
                if (-not $State.PSObject.Properties['deliveredDaily']) { $State | Add-Member -NotePropertyName deliveredDaily -NotePropertyValue @() }
                $State.deliveredDaily = @($State.deliveredDaily) + @([pscustomobject]@{ reportId = [string]$report.reportId; reportDate = [string]$report.reportDate; deliveredAt = $At.ToString('o') })
                $auditCutoff = $At.Date.AddDays(-7)
                $State.deliveredDaily = @($State.deliveredDaily | Where-Object { [datetime]::Parse([string]$_.deliveredAt) -ge $auditCutoff })
            }
            $sent++
        }
        catch {
            $State.lastError = ('Upload failed: ' + $_.Exception.Message)
            break
        }
    }
    return [pscustomobject]@{ State = $State; Sent = $sent; Remaining = @($State.pending).Count }
}

function Write-HealthLog {
    param([string]$Path, [string]$Message, [datetime]$At = (Get-Date))
    $directory = Split-Path -Parent $Path
    if (-not (Test-Path -LiteralPath $directory)) { New-Item -ItemType Directory -Path $directory -Force | Out-Null }
    if ((Test-Path -LiteralPath $Path) -and (Get-Item -LiteralPath $Path).Length -gt 1MB) {
        Move-Item -LiteralPath $Path -Destination ($Path + '.previous') -Force
    }
    Add-Content -LiteralPath $Path -Value ('{0:o} {1}' -f $At, $Message) -Encoding UTF8
}

Export-ModuleMember -Function *
