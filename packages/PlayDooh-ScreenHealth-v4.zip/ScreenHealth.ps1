[CmdletBinding()]
param(
    [ValidateSet('Check', 'Upload', 'Status')][string]$Mode = 'Check',
    [string]$DataRoot = (Join-Path $env:ProgramData 'PlayDooh\ScreenHealth')
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Import-Module (Join-Path $PSScriptRoot 'ScreenHealth.Core.psm1') -Force

$configPath = Join-Path $DataRoot 'config.json'
$statePath = Join-Path $DataRoot 'state.json'
$logPath = Join-Path $DataRoot 'logs\screen-health.log'
if (-not (Test-Path -LiteralPath $configPath)) { throw "Screen Health is not installed: $configPath" }
$config = Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json
$monitorVersion = if ($config.PSObject.Properties['monitorVersion']) { [string]$config.monitorVersion } else { 'v2' }
$updaterVersionPath = Join-Path $env:ProgramData 'PlayDooh\ScreenHealthUpdater\VERSION.txt'
$updaterVersion = if (Test-Path -LiteralPath $updaterVersionPath) { (Get-Content -LiteralPath $updaterVersionPath -Raw).Trim() } else { '' }
$monitoringStartedAt = if ($config.PSObject.Properties['installedAt'] -and -not [string]::IsNullOrWhiteSpace([string]$config.installedAt)) { [datetime]::Parse([string]$config.installedAt) } else { Get-Date }

$mutexName = 'Global\PlayDoohScreenHealth-' + ((Get-StableUInt32 -Text ([string]$config.screenId)).ToString('X8'))
$mutex = New-Object Threading.Mutex($false, $mutexName)
if (-not $mutex.WaitOne(0)) { exit 0 }
try {
    $now = Get-Date
    $state = Read-State -Path $statePath -ScreenId ([string]$config.screenId)
    switch ($Mode) {
        'Check' {
            if (Test-RestartGap -At $now) { Write-HealthLog -Path $logPath -Message 'Connectivity check skipped for the 04:30 restart window.' -At $now; break }
            $online = Test-InternetOnline -TimeoutSeconds 5
            $state = Add-ConnectivityResult -State $state -At $now -Online $online
            Remove-OldDailyEntries -State $state -At $now
            Write-State -State $state -Path $statePath
            Write-HealthLog -Path $logPath -Message ('Connectivity check: ' + $(if ($online) { 'online' } else { 'offline' })) -At $now
        }
        'Upload' {
            # Preserve and send any older weekly packages first, then add today's rolling snapshot.
            $crashesLast7Days = Get-UnexpectedShutdownCount -Start $now.Date.AddDays(-7) -End $now.Date
            $crashesLast30Days = Get-UnexpectedShutdownCount -Start $now.Date.AddDays(-30) -End $now.Date
            $state = Add-DailySnapshotReport -State $state -ScreenId ([string]$config.screenId) -At $now -MonitoringStartedAt $monitoringStartedAt -CheckMinute ([int]$config.checkMinute) -MonitorVersion $monitorVersion -UpdaterVersion $updaterVersion -CrashesLast7Days $crashesLast7Days -CrashesLast30Days $crashesLast30Days
            $token = Unprotect-ReceiverToken -ProtectedToken ([string]$config.protectedToken)
            $outcome = Send-PendingReports -State $state -Endpoint ([string]$config.endpoint) -Token $token -At $now
            # Thirty days are required for rolling calculations; five extra days tolerate delayed runs.
            Remove-OldDailyEntries -State $outcome.State -At $now -KeepDays 35
            Write-State -State $outcome.State -Path $statePath
            Write-HealthLog -Path $logPath -Message ("Upload run: sent {0}; remaining {1}." -f $outcome.Sent, $outcome.Remaining) -At $now
        }
        'Status' {
            $currentWeekStart = ConvertFrom-DateKey -DateKey (Get-ReportWeek -At $now)
            $crashesThisWeek = Get-UnexpectedShutdownCount -Start $currentWeekStart -End $now
            Write-Host 'Configuration and upload status'
            [pscustomobject]@{
                ScreenId           = [string]$config.screenId
                MonitorVersion     = $monitorVersion
                UpdaterVersion     = $(if ([string]::IsNullOrWhiteSpace($updaterVersion)) { 'Not installed' } else { $updaterVersion })
                MonitoringStarted  = $monitoringStartedAt.ToString('yyyy-MM-dd HH:mm:ss')
                CheckMinute        = [int]$config.checkMinute
                UploadTime         = [string]$config.uploadTime
                CrashesThisWeek    = $crashesThisWeek
                LastCheckAt        = $state.lastCheckAt
                LastUploadAt       = $state.lastUploadAt
                LastSuccessfulWeek = $state.lastSuccessfulWeek
                PendingReports     = @($state.pending).Count
                LastError          = $state.lastError
            } | Format-List
            Write-Host 'Last 7 days - hourly connectivity checks'
            Get-LocalSevenDayStatus -State $state -MonitoringStartedAt $monitoringStartedAt -CheckMinute ([int]$config.checkMinute) -At $now |
                Format-Table Date, Day, Online, Offline, Checks, Coverage, Result -AutoSize
            Write-Host 'An Offline value above 0 means at least one hourly check failed that day.'
        }
    }
}
catch {
    Write-HealthLog -Path $logPath -Message ('ERROR ' + $_.Exception.Message)
    throw
}
finally {
    $mutex.ReleaseMutex()
    $mutex.Dispose()
}
